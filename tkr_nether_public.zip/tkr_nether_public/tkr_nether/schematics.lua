local path = minetest.get_modpath("tkr_nether_public") .. "/schematics/"
local dpath = minetest.get_modpath("default") .. "/schematics/" 
   
minetest.register_decoration({
		deco_type = "schematic",
		place_on = {"nether:rack"},
		sidelen = 80,
		noise_params = {
			offset = -0.0005,
			scale = 0.0015,
			spread = {x = 200, y = 200, z = 200},
			seed = 230,
			octaves = 3,
			persist = 0.00001
		},
		biomes = {"nether_caverns"},
		schematic = path .. "gold_hoard.mts",
		flags = "place_center_x",
		rotation = "random",
	})

