minetest.register_node(":nether:rack_with_dragonscale_fragments", {
	description = ("Nether Rack with dragonscale fragments"),
	tiles = {"dragonscale_infused_nether_rack.png"},
	groups = {stone=2, cracky=3},
	drop = "nether:unrefined_dragonscale_fragment",
	is_ground_content = true,
})

minetest.register_node(":nether:rack_deep_with_dragonscale_fragments", {
	description = ("Deep Nether Rack with dragonscale fragments"),
	tiles = {"dragonscale_infused_deep_nether_rack.png"},
	groups = {stone=2, cracky=3},
	drop = "nether:unrefined_dragonscale_fragment",
	is_ground_content = true,
})

minetest.register_node(":nether:basalt_with_dragonscale_fragments", {
	description = ("Nether basalt with dragonscale fragments"),
	tiles = {"dragonscale_infused_nether_basalt.png",
	         "dragonscale_infused_nether_basalt.png",
	        "nether_basalt_with_dragonscale_side.png",
	        "nether_basalt_with_dragonscale_side.png",
	         "nether_basalt_with_dragonscale_side.png",
	        "nether_basalt_with_dragonscale_side.png"},
	groups = {stone=2, cracky=3},
	drop = "nether:unrefined_dragonscale_fragment",
	is_ground_content = true,
})


minetest.register_craftitem(":nether:dragonscale_fragment", {
	description = ("Dragonscale Fragment"),
	inventory_image = "dragonscale_fragment.png",
})

minetest.register_craftitem(":nether:unrefined_dragonscale_fragment", {
	description = (" Unrefined Dragonscale Fragment"),
	inventory_image = "dragonscale_fragment_unrefined.png",
})

minetest.register_node(":nether:nether_block", {
	description = ("Nether Block"),
	tiles = {"nether_nether_block.png"},
	groups = {stone=2, cracky=3},
	is_ground_content = false,
})

minetest.register_node(":nether:nether_block_carved", {
	description = ("Carved Nether Block"),
	tiles = {"nether_nether_block_carved.png"},
	groups = {stone=2, cracky=3},
	paramtype = "light",
	light_source = 8,
	is_ground_content = false,
})
